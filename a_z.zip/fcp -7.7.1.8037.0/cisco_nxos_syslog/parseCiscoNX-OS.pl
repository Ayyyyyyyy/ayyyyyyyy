#!/usr/bin/perl
sub getFields {
	my $line = $_[0];
    $line =~ s/([()])/\\\\$1/g;
    $line =~ s/\s+/ /g;
    $line =~ s/\s*\\n//g;
	my @params=(); my $count=0; 
    while($line =~ s/\b(initiator|target|saddr)([, =:('"\\]*)\[(\S+)\]/$1$2(\\\\d+\.\\\\d+\.\\\\d+\.\\\\d+)/i) {$params[$count++]="additionaldata.".$1}
    while($line =~ s/\b(service|protocol|prot|interface|port|slot|card|file|process|cmd|received|message|reported|error|warning|msg|rsn|cause|failed|due.to|mac|url|site|list|transfered|ip|ipaddress|by|hostname|grp|uri|module|vsan|fcid|ch|chi|ccw|token|cmd|ips|iscsi|fcip|iscsi-intf-vsan|ips-lc|node|id|asic|tcam|bank|sid|did|vlan|pgid|vdh|key|lun|initiator|target|saddr|ip|reason)([, =:('"\\]*)\[(\S+)\]/$1$2(.*?)/i) {$params[$count++]="additionaldata.".$1}
    while($line =~ s/\[(\S+?)\]([, =:('"\\]*)(bytes|packets|packet\[|packet |session )/(.*?)$2$3/i) {$params[$count++]="additionaldata.$3"}
	$line =~ s/\[.*?\]/.*?/g;	
#add this code to handle %s, %d, %x, %u, %i
	$line =~ s/\%s|\%d|\%x|\%u|\%i/.*?/g;
    $line =~ s/([\[\]{}\.])/\\\\$1/g;
#add this code to handle generated regex (\\.*?). It will replace (\\.*?) to (.*?)
	$line =~ s/(\\\\\.\*)/.*/g;
    if ($line !=~ /\(\.\*\?\)/ && $line =~ /^\W+$/) { $line = "(.*?)"; $params[$count++]="event.name" }
#    if (scalar @params == 0) { $line =~ s/^(.*)$/($1)/; $params[0]="event.name"}
	my $params=join ',', @params; $params =~ s/([\[\]])(.)/$1\u$2/g; $params =~ s/[\[\]]//g; 
	$params =~ s/additionaldata.(bytes|transfered)/event.bytesIn/gi;
	$params =~ s/additionaldata.(by)/event.sourceUserName/gi;
	$params =~ s/additionaldata.(packet |session )/event.transportProtocol/gi;
	$params =~ s/additionaldata.(packets|packet)/event.deviceCustomNumber2/gi;
	$params =~ s/additionaldata.(hostname)/event.destinationHostName/gi;
	$params =~ s/additionaldata.(reason)/event.reason/gi;
	$params =~ s/additionaldata.(initiator|client|host|.?cli|-|src|by|agent|saddr)/event.sourceAddress/gi;
	$params =~ s/additionaldata.(manager|ip.address|ip|address|peer|server|down|operational|for|nexthop|hop|to|dest_addr|destadr|at|declined|pinged|drp|svr|destination|neighbor|was|responder|address|gsn|dst|entry|self|using|at|=>|cache|located|rp|c.rp)/event.destinationAddress/gi;
    $params =~ s/additionaldata.mac/event.destinationMacAddress/gi;
	$params =~ s/additionaldata.service/event.applicationProtocol/gi;
	$params =~ s/additionaldata.(protocol|prot)/event.transportProtocol/gi;
	$params =~ s/additionaldata.(interface|port|on)/event.deviceInboundInterface/gi;
	$params =~ s/additionaldata.(slot|card)/event.deviceCustomString1/gi;
	$params =~ s/additionaldata.file/event.fileName/gi;
#	$params =~ s/additionaldata.(process|cmd)/event.deviceProcessName/gi; # commented out because deviceProcessName was creating a new devicedescriptor
	$params =~ s/additionaldata.(url|site)/event.requestUrl/gi;
	$params =~ s/additionaldata.list/event.deviceCustomString6/gi;
	$params =~ s/additionaldata.(received|message|reported|error|warning|msg|rsn|cause|failed|due.to)/event.message/gi;
	$params =~ s/additionaldata.\\(\\\\d+\\\\.\\\\d+\\\\.\\\\d+\\\\.\\\\d+)\/?/additionaldata.address/gi;
    return ($line,$params)
}

while(<>){
# 'Format': support for v7 - if (/^(\S+?)-(\d+)-(\S+?) Format: (.*)/)
#  Without 'Format': support for v5 - if (/^(\S+?)-(\d+)-(\S+?): (.*)/)
	chomp;
    if (/^(\S+?)-(\d+)-(\S+?)(?: Format)?: (.*)/){$fac=$1;$sev=$2;$msg=$3;$message=$4;$inmessage=1;}
    elsif ($inmessage && !/^Explanation/) {$message.=" $_"}
    elsif (/^Explanation    (.*)/) {$explanation=$1;$inmessage=0;$inexpl=1}
    elsif ($inexpl && !/^Recommended/) {$explanation.=$_}
    elsif (/^Recommended/) {
        $inexpl=0;
        $messages{"$fac-$sev-$msg"}=$message;
        $explanations{"$fac-$sev-$msg"}=$explanation;
    }
}
$submessagecount=0;
print "submessage.count=".scalar(keys(%messages)). "\n\n";
foreach $key (sort keys %messages) {
#$comment variable to contain pattern sample that uses for comment message
    my $comment = "$key: $messages{$key}";
	my $message = $messages{$key}; ($message, my $fields) = getFields $message;
    print "# $explanations{$key}\n";
    print "submessage[$submessagecount].messageid=$key\n";
    print "submessage[$submessagecount].pattern.count=1\n\n";
#generate comment
	print "# $comment\n";
    print "submessage[$submessagecount].pattern[0].regex=$message\n";
    print "submessage[$submessagecount].pattern[0].fields=$fields\n";
    my $extra=$message; $extra =~ s/\(.*?\)//g; $extra =~ s/(\.[^*\\]).*//; $extra =~ s/[^\w \-!: \%]//g; $extra =~ s/^\W*(.*?)\W*$/$1/; $extra =~ s/\s+/ /g; $extra =~ s/^[,: ]+//; $extra =~ s/[,: ]+$//; $extra =~ s/(\s+(at|to.port|to|of|met|for.port|for|as|with|by|is|on|in|from)$)//;
    my $nameconstant="";
    if ($extra) { $nameconstant = "event.name=__stringConstant($extra)" }
    if ($key =~ m/^(telnet|http|ftp|ssh|snmp|smtp|psh|netbios|pppoe|pptp|ppp)/i) {$nameconstant.="|event.applicationProtocol=__stringConstant($1)"}
#add "#======================================" to seperate submessage
    if ($nameconstant) {print "submessage[$submessagecount].pattern[0].extramappings=$nameconstant\n\n#======================================\n\n"}
    else {print "\n\n#======================================\n\n"}
    $submessagecount++;
}
